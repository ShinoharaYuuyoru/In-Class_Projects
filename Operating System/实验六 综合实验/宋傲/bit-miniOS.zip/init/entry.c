#include "types.h"
#include "console.h"
#include "string.h"
#include "os/kernel.h"

int kern_entry()
{
    console_clear();

    console_puts("Hello World\n\n",dc_black,dc_green);
    console_puts("Hello World\n\n",dc_blue,dc_green);
    console_puts("Hello World\n\n",dc_black,dc_red);
    /*
    char *src = "hello";
    uint32_t len = strlen(src);

    console_puti(len,dc_black,dc_green);

    printk("Hello World\n");*/


    return 0;
}
