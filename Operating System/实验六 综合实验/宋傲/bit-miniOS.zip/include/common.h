#ifndef INCLUDE_COMMON_H
#define INCLUDE_COMMON_H

#include "types.h"

//向端口写字节
void outb(uint16_t port,uint8_t value);

//读端口字节
uint8_t inb(uint16_t port);

//读端口字
uint16_t inw(uint16_t port);

#endif