package bit.minisys.minicc.parser;

public class re
{
  String s;
  int i;
  
  public re() {}
}
