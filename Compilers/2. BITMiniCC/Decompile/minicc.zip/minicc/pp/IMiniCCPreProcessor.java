package bit.minisys.minicc.pp;

public abstract interface IMiniCCPreProcessor
{
  public abstract void run(String paramString1, String paramString2);
}
