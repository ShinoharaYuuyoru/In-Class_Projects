package bit.minisys.minicc.simulator;

import mars.MarsLaunch;

public class MIPSSimulator implements IMIPSSimulator {
  public MIPSSimulator() {}
  
  public void run(String iFile) {
    String[] args = new String[0];
    new MarsLaunch(args);
    














    System.out.println("8. Simulate not finished!");
  }
}
