package bit.minisys.minicc.simulator;

public abstract interface IMIPSSimulator
{
  public abstract void run(String paramString);
}
